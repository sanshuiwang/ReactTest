## Removing `sanitize.css`

Delete [lines 31 and 32 in `app.js`](../../app/app.js#L31-L32) and remove it
from the `dependencies` in [`package.json`](../../package.json)!
